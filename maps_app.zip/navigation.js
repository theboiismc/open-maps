import { safeFetch, showToast } from './utils.js';
import { setSheetState } from './bottomSheet.js';

export async function loadNavigation(sidePanel) {
  try {
    const res = await safeFetch('/api/navigation');
    const data = await res.json();
    renderNav(sidePanel, data);
  } catch (err) {
    console.error('Navigation load failed', err);
    showToast('Failed to load navigation', 'error');
  }
}

function renderNav(container, navData) {
  container.innerHTML = '';
  navData.forEach(item => {
    const el = document.createElement('button');
    el.textContent = item.name;
    el.onclick = () => handleNavClick(item);
    container.appendChild(el);
  });
}

function handleNavClick(item) {
  if (item.action === 'close') {
    setSheetState(document.getElementById('bottom-sheet'), 'closed');
  } else if (item.url) {
    window.location.href = item.url;
  }
}