import { safeFetch, showToast } from './utils.js';

export async function loadTraffic(map) {
  try {
    const res = await safeFetch('/api/traffic');
    const data = await res.json();
    renderTraffic(map, data);
  } catch (err) {
    console.error('Traffic load failed', err);
    showToast('Traffic load failed', 'error');
  }
}

function renderTraffic(map, geojson) {
  if (map.getSource('traffic')) map.removeLayer('traffic');
  if (map.getSource('traffic')) map.removeSource('traffic');

  map.addSource('traffic', { type: 'geojson', data: geojson });
  map.addLayer({
    id: 'traffic',
    type: 'line',
    source: 'traffic',
    layout: { 'line-join': 'round', 'line-cap': 'round' },
    paint: { 'line-color': '#ef4444', 'line-width': 3, 'line-opacity': 0.6 }
  });
}