import { safeFetch, showToast, debounce } from './utils.js';
import { setSheetState } from './bottomSheet.js';

export function initSearch(inputEl, resultsEl) {
  inputEl.addEventListener('input', debounce(async (e) => {
    const q = e.target.value.trim();
    if (!q) return resultsEl.innerHTML = '';
    try {
      const res = await safeFetch(`/api/search?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      renderResults(resultsEl, data);
    } catch (err) {
      console.error('Search error', err);
      showToast('Search failed', 'error');
    }
  }, 300));
}

function renderResults(container, results) {
  container.innerHTML = '';
  results.forEach(r => {
    const div = document.createElement('div');
    div.className = 'search-result';
    div.textContent = r.title;
    div.onclick = () => window.location.href = r.url;
    container.appendChild(div);
  });
}