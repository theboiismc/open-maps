import { safeFetch, showToast } from './utils.js';
import { setSheetState } from './bottomSheet.js';

export async function calculateRoute(from, to, map) {
  try {
    const res = await safeFetch(`/api/route?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`);
    const data = await res.json();
    if (!data || !data.geojson) throw new Error('Invalid route data');
    addRouteLayer(map, data.geojson);
  } catch (err) {
    console.error('Routing error', err);
    showToast('Route calculation failed', 'error');
  }
}

function addRouteLayer(map, geojson) {
  if (map.getSource('route')) map.removeLayer('route');
  if (map.getSource('route')) map.removeSource('route');

  map.addSource('route', { type: 'geojson', data: geojson });
  map.addLayer({
    id: 'route',
    type: 'line',
    source: 'route',
    layout: { 'line-join': 'round', 'line-cap': 'round' },
    paint: { 'line-color': '#3b82f6', 'line-width': 5 }
  });
}