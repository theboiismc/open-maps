import { safeFetch, showToast } from './utils.js';

export async function loadWeather(container) {
  try {
    const res = await safeFetch('/api/weather');
    const data = await res.json();
    renderWeather(container, data);
  } catch (err) {
    console.error('Weather load failed', err);
    showToast('Failed to load weather', 'error');
  }
}

function renderWeather(container, data) {
  container.innerHTML = `
    <div class="weather-temp">${Math.round(data.temp)}°C</div>
    <div class="weather-cond">${data.condition}</div>
  `;
}